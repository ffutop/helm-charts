# data-diode-connector-ingress

![Version: 1.0.0](https://img.shields.io/badge/Version-1.0.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.0.0](https://img.shields.io/badge/AppVersion-1.0.0-informational?style=flat-square)

A Helm chart for Kubernetes to deploy the Data Diode Connector Ingress

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` |  |
| filters[0].bipBufferElementCount | int | `10` | The maximum amount of elements the bip buffer can store. The size of a single element is 1Mb |
| filters[0].enabled | bool | `false` |  |
| filters[0].fromHostSysLog | string | `"0.0.0.0"` | From syslog server address |
| filters[0].fromPortSysLog | int | `8127` | From syslog server port |
| filters[0].handlerName | string | `"filter"` | Name of the handler |
| filters[0].hostStatsServer | string | `"127.0.0.1"` | The address of the stats server |
| filters[0].logLevel | string | `"Warn"` | Log level for logging [Trace, Debug, Info, Warn, Error] |
| filters[0].maxMessageSize | int | `1050000` | The maximum message size in bytes |
| filters[0].name | string | `"default-filter"` |  |
| filters[0].portStatsServer | int | `8125` | The port of the stats server |
| filters[0].securityContext | object | `{}` |  |
| filters[0].toHostSysLog | string | `"127.0.0.1"` | To syslog udp address |
| filters[0].toPortSysLog | int | `8082` | To syslog udp port |
| filters[0].wordToFilter | string | `"secret"` | The word to filter out |
| fullnameOverride | string | `""` |  |
| imagePullSecrets | list | `[]` |  |
| images.filter.pullPolicy | string | `"IfNotPresent"` |  |
| images.filter.repository | string | `"ffutop/ddc-filter"` |  |
| images.filter.tag | string | `"latest"` |  |
| images.fluentbit.pullPolicy | string | `"IfNotPresent"` |  |
| images.fluentbit.repository | string | `"fluent/fluent-bit"` |  |
| images.fluentbit.tag | string | `"4.2.0"` |  |
| images.phKafkaIngress.pullPolicy | string | `"IfNotPresent"` |  |
| images.phKafkaIngress.repository | string | `"ffutop/ddc-ph-kafka-ingress"` |  |
| images.phKafkaIngress.tag | string | `"latest"` |  |
| images.phUdpIngress.pullPolicy | string | `"IfNotPresent"` |  |
| images.phUdpIngress.repository | string | `"ffutop/ddc-ph-udp-ingress"` |  |
| images.phUdpIngress.tag | string | `"latest"` |  |
| images.registry | string | `""` |  |
| images.transportUdpSend.pullPolicy | string | `"IfNotPresent"` |  |
| images.transportUdpSend.repository | string | `"ffutop/ddc-transport-udp-send"` |  |
| images.transportUdpSend.tag | string | `"latest"` |  |
| nameOverride | string | `""` |  |
| nodeSelector | object | `{}` |  |
| podAnnotations | object | `{}` |  |
| podSecurityContext | object | `{}` |  |
| protocolHandler.kafka.bipBufferElementCount | int | `2` | The maximum amount of elements the bip buffer can store. The size of a single element is 1Mb |
| protocolHandler.kafka.fromHostSysLog | string | `"0.0.0.0"` | From syslog server address |
| protocolHandler.kafka.fromPortSysLog | int | `8127` | From syslog server port |
| protocolHandler.kafka.handlerName | string | `"ph_kafka_ingress"` | Name of the handler |
| protocolHandler.kafka.hostKafkaServer | string | `"kafka.kafka.svc.cluster.local"` | The Kafka server host |
| protocolHandler.kafka.logLevel | string | `"Warn"` | Log level for logging [Trace, Debug, Info, Warn, Error] |
| protocolHandler.kafka.maxBytesPerPartition | int | `1000000` | The maximum number of bytes per partition to fetch from Kafka |
| protocolHandler.kafka.portKafkaServer | int | `9092` | The Kafka server port |
| protocolHandler.kafka.securityContext | object | `{}` |  |
| protocolHandler.kafka.statsServerAddress | string | `"0.0.0.0"` | The address of the stats server |
| protocolHandler.kafka.statsServerPort | int | `8081` | The port of the stats server |
| protocolHandler.kafka.toHostSysLog | string | `"127.0.0.1"` | To syslog udp address |
| protocolHandler.kafka.toPortSysLog | int | `8082` | To syslog udp port |
| protocolHandler.kafka.topicName | string | `"TestTopic"` | The Kafka topic name to subscribe to |
| protocolHandler.type | string | `"kafka"` |  |
| protocolHandler.udp.bipBufferElementCount | int | `10` | The maximum amount of elements the bip buffer can store. The size of a single element is 1Mb |
| protocolHandler.udp.fromHostSysLog | string | `"0.0.0.0"` | From syslog server address |
| protocolHandler.udp.fromPortSysLog | int | `8127` | From syslog server port |
| protocolHandler.udp.handlerName | string | `"ph_udp_ingress"` | Name of the handler |
| protocolHandler.udp.listeningPort | int | `1235` | Listening port for the UDP server |
| protocolHandler.udp.logLevel | string | `"Warn"` | Log level for logging [Trace, Debug, Info, Warn, Error] |
| protocolHandler.udp.securityContext | object | `{}` |  |
| protocolHandler.udp.statsServerAddress | string | `"127.0.0.1"` | The address of the stats server |
| protocolHandler.udp.statsServerPort | int | `8125` | The port of the stats server |
| protocolHandler.udp.toHostSysLog | string | `"127.0.0.1"` | To syslog udp address |
| protocolHandler.udp.toPortSysLog | int | `8082` | To syslog udp port |
| replicaCount | int | `1` |  |
| resources | object | `{}` |  |
| serviceAccount.annotations | object | `{}` |  |
| serviceAccount.create | bool | `true` |  |
| serviceAccount.name | string | `""` |  |
| tolerations | list | `[]` |  |
| transportUdpSend.bipBufferElementCount | int | `10` | The maximum amount of elements the bip buffer can store. The size of a single element is 1Mb |
| transportUdpSend.fromHostSysLog | string | `"0.0.0.0"` | From syslog server address |
| transportUdpSend.fromPortSysLog | int | `8343` | From syslog server port |
| transportUdpSend.handlerName | string | `"transport_udp_send"` | Name of the handler |
| transportUdpSend.logLevel | string | `"Warn"` | Log level for logging [Trace, Debug, Info, Warn, Error] |
| transportUdpSend.receiverAddress | string | `"0.0.0.0"` | Address the receiver is hosted on |
| transportUdpSend.receiverPort | int | `1234` | Port the receiver should be listening on |
| transportUdpSend.securityContext.capabilities.add[0] | string | `"SYS_NICE"` |  |
| transportUdpSend.sendDelayMs | int | `5` | Send delay in milliseconds used for every UDP message |
| transportUdpSend.senderAddress | string | `"0.0.0.0"` | Address the sender is hosted on |
| transportUdpSend.senderPort | int | `33333` | Port the sender is listening on |
| transportUdpSend.statsServerAddress | string | `"0.0.0.0"` | The address of the stats server |
| transportUdpSend.statsServerPort | int | `8081` | The port of the stats server |
| transportUdpSend.toHostSysLog | string | `"127.0.0.1"` | To syslog udp address |
| transportUdpSend.toPortSysLog | int | `8082` | To syslog udp port |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
