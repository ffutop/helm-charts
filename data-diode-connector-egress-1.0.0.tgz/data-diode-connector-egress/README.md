# data-diode-connector-egress

![Version: 1.0.0](https://img.shields.io/badge/Version-1.0.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.0.0](https://img.shields.io/badge/AppVersion-1.0.0-informational?style=flat-square)

## 🚀 Introduction

The **Data Diode Connector Egress** is the critical *receiving* component of the open-source [Data Diode Connector](https://data-diode-connector.ffutop.com?utm_source=artifacthub&utm_medium=readme&utm_campaign=egress) project.

Designed for high-security environments (OT/ICS, Defense, Critical Infrastructure), this Helm chart deploys the Egress service which collects data from your secure network and transmits it via a strictly unidirectional UDP stream to the Ingress component.

> **🔒 Core Value:** Physical and Logical network isolation while maintaining real-time data flow.

## ✨ Key Features

- **Strict Unidirectional Transport:** enforcing one-way data flow at the software level (UDP).
- **High-Throughput Rust Core:** Optimized for minimal latency and maximum packet density.
- **Configurable Inputs:** Supports collecting data from Kafka, raw UDP, or TCP sockets.
- **Observability:** Built-in Prometheus metrics for monitoring packet loss and throughput.

## 📚 Documentation & Support

For comprehensive deployment guides, architectural details, and hardware setup examples, please visit our **[Official Documentation](https://data-diode-connector.ffutop.com?utm_source=artifacthub&utm_medium=readme&utm_campaign=egress)**.

- [Architecture Overview](https://data-diode-connector.ffutop.com/en/software_architecture.html)
- [Configuration Reference](https://data-diode-connector.ffutop.com/en/configuration_reference.html)
- [Deployment Topologies](https://data-diode-connector.ffutop.com/en/deployment_topologies.html)

A Helm chart for Kubernetes to deploy the Data Diode Connector Egress. Securely receives and processes unidirectional data streams.

**Homepage:** <https://data-diode-connector.ffutop.com>

**Official Site:** <https://data-diode-connector.ffutop.com>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| ffutop | <lijinling.me@gmail.com> |  |

## Source Code

* <https://github.com/ffutop/DataDiodeConnector>
* <https://data-diode-connector.ffutop.com/docs>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` |  |
| filters[0].bipBufferElementCount | int | `10` | The maximum amount of elements the bip buffer can store. The size of a single element is 1Mb |
| filters[0].enabled | bool | `false` |  |
| filters[0].fromHostSysLog | string | `"0.0.0.0"` | From syslog server address |
| filters[0].fromPortSysLog | int | `8130` | From syslog server port |
| filters[0].handlerName | string | `"filter"` | Name of the handler |
| filters[0].logLevel | string | `"Warn"` | Log level for logging [Trace, Debug, Info, Warn, Error] |
| filters[0].maxMessageSize | int | `1050000` | The maximum message size in bytes |
| filters[0].name | string | `"default-filter"` |  |
| filters[0].securityContext | object | `{}` |  |
| filters[0].statsServerAddress | string | `"127.0.0.1"` | The address of the stats server |
| filters[0].statsServerPort | int | `8125` | The port of the stats server |
| filters[0].toHostSysLog | string | `"127.0.0.1"` | To syslog udp address |
| filters[0].toPortSysLog | int | `8082` | To syslog udp port |
| filters[0].wordToFilter | string | `"secret"` | The word to filter out |
| fullnameOverride | string | `""` |  |
| imagePullSecrets | list | `[]` |  |
| images.filter.pullPolicy | string | `"IfNotPresent"` |  |
| images.filter.repository | string | `"ffutop/ddc-filter"` |  |
| images.filter.tag | string | `"latest"` |  |
| images.phKafkaEgress.pullPolicy | string | `"IfNotPresent"` |  |
| images.phKafkaEgress.repository | string | `"ffutop/ddc-ph-kafka-egress"` |  |
| images.phKafkaEgress.tag | string | `"latest"` |  |
| images.phUdpEgress.pullPolicy | string | `"IfNotPresent"` |  |
| images.phUdpEgress.repository | string | `"ffutop/ddc-ph-udp-egress"` |  |
| images.phUdpEgress.tag | string | `"latest"` |  |
| images.registry | string | `""` |  |
| images.transportUdpReceive.pullPolicy | string | `"IfNotPresent"` |  |
| images.transportUdpReceive.repository | string | `"ffutop/ddc-transport-udp-receive"` |  |
| images.transportUdpReceive.tag | string | `"latest"` |  |
| images.vector.pullPolicy | string | `"IfNotPresent"` |  |
| images.vector.repository | string | `"timberio/vector"` |  |
| images.vector.tag | string | `"0.51.1-alpine"` |  |
| nameOverride | string | `""` |  |
| nodeSelector | object | `{}` |  |
| podAnnotations | object | `{}` |  |
| podSecurityContext | object | `{}` |  |
| protocolHandler.kafka.bipBufferElementCount | int | `10` | The maximum amount of elements the bip buffer can store. The size of a single element is 1Mb |
| protocolHandler.kafka.fromHostSysLog | string | `"0.0.0.0"` | From syslog server host |
| protocolHandler.kafka.fromPortSysLog | int | `8129` | From syslog server port |
| protocolHandler.kafka.handlerName | string | `"ph-kafka-egress"` | Name of the handler |
| protocolHandler.kafka.hostKafkaServer | string | `"kafka.kafka.svc.cluster.local"` | kafka server host |
| protocolHandler.kafka.inReplacement | string | `"TestTopic"` | Topic to replace |
| protocolHandler.kafka.logLevel | string | `"Info"` | Log level for logging |
| protocolHandler.kafka.outReplacement | string | `"FinalTestTopic"` | replace topic |
| protocolHandler.kafka.portKafkaServer | int | `9092` | kafka server port |
| protocolHandler.kafka.securityContext | object | `{}` |  |
| protocolHandler.kafka.statsServerAddress | string | `"127.0.0.1"` | The address of the stats server |
| protocolHandler.kafka.statsServerPort | int | `8125` | The port of the stats server |
| protocolHandler.kafka.toHostSysLog | string | `"127.0.0.1"` | To syslog server host |
| protocolHandler.kafka.toPortSysLog | int | `8082` | To syslog server port |
| protocolHandler.type | string | `"kafka"` |  |
| protocolHandler.udp.bipBufferElementCount | int | `10` | The maximum amount of elements the bip buffer can store. The size of a single element is 1Mb |
| protocolHandler.udp.fromHostSysLog | string | `"0.0.0.0"` | From syslog server host |
| protocolHandler.udp.fromPortSysLog | int | `8129` | From syslog server port |
| protocolHandler.udp.handlerName | string | `"ph-udp-egress"` | Name of the handler |
| protocolHandler.udp.logLevel | string | `"Info"` | Log level for logging |
| protocolHandler.udp.securityContext | object | `{}` |  |
| protocolHandler.udp.statsServerAddress | string | `"127.0.0.1"` | The address of the stats server |
| protocolHandler.udp.statsServerPort | int | `8125` | The port of the stats server |
| protocolHandler.udp.toHostSysLog | string | `"127.0.0.1"` | To syslog server host |
| protocolHandler.udp.toPortSysLog | int | `8082` | To syslog server port |
| protocolHandler.udp.udpReceiverHost | string | `"0.0.0.0"` | The address of the UDP receiver |
| protocolHandler.udp.udpReceiverPort | int | `1235` | The port of the UDP receiver |
| replicaCount | int | `1` |  |
| resources | object | `{}` |  |
| service.type | string | `"ClusterIP"` |  |
| serviceAccount.annotations | object | `{}` |  |
| serviceAccount.create | bool | `true` |  |
| serviceAccount.name | string | `""` |  |
| tolerations | list | `[]` |  |
| transportUdpReceive.bipBufferElementCount | int | `10` | The maximum amount of elements the bip buffer can store. The size of a single element is 1Mb |
| transportUdpReceive.fromHostSysLog | string | `"0.0.0.0"` | From syslog server host |
| transportUdpReceive.fromPortSysLog | int | `8342` | From syslog server port |
| transportUdpReceive.handlerName | string | `"transport-udp-receive"` | Name of the handler |
| transportUdpReceive.logLevel | string | `"Info"` | Log level for logging |
| transportUdpReceive.receiverAddress | string | `"0.0.0.0"` | Address the receiver is host on |
| transportUdpReceive.receiverPort | int | `1234` | Port the receiver should be listening on |
| transportUdpReceive.securityContext.capabilities.add[0] | string | `"SYS_NICE"` |  |
| transportUdpReceive.statsServerAddress | string | `"127.0.0.1"` | The address of the stats server |
| transportUdpReceive.statsServerPort | int | `8125` | The port of the stats server |
| transportUdpReceive.toHostSysLog | string | `"127.0.0.1"` | To syslog server host |
| transportUdpReceive.toPortSysLog | int | `8082` | To syslog server port |

